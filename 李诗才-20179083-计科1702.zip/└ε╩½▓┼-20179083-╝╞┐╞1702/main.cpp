#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
using namespace std;

#define ll long long int

const int C[]={30,50,80,100};   // 设置不同数量级的皇后初始化冲突数量
ll n = 3000000;		 		// 皇后数量
FILE *out=fopen("D:\\million_queen.txt","w");		// 保存符合条件的 N 皇后的编码
ll m;					// 不冲突的皇后数量

// 根据皇后数量级返回初始化冲突的皇后数量
int conflict(ll n)
{
	if(n<=10)	return (n>8) ? 8 : n;
	else if (n<100)		return n;
	else if (n<1000)	return C[0];
	else if (n<10000)	return C[1];
	else if (n<100000)	return C[2];
	else				return C[3];
}

int main()
{
	cout<<"Please enter the queen number:";
	cin>>n;

	void QS4();

	m = n - conflict(n);	// m 是不冲突的皇后数
    QS4();  // Queen Search 4 算法
    fclose(out);    //关闭文件
}

unsigned ll RandSeed = (unsigned)time(NULL);

unsigned ll BRandom(ll max)
{
	unsigned ll x ;
	double i ;

	x = 0x7fffffff;
	x += 1;
	RandSeed *= ((unsigned ll)134775813);
	RandSeed += 1;
	RandSeed = RandSeed % x;
	i = ((double)RandSeed) / (double)0x7fffffff;

	return (unsigned ll)(max * i);
}

// 交换a与b的值
void swap(ll &a, ll &b)
{
	if (a!=b)
	{
		ll t;
		t = a;
		a = b;
		b = t;
	}
}

// 重置皇后
void init_4(ll queen[], ll n, ll m, ll b[], ll c[])
{
	ll i, last;
	ll z;

	// 维护对角线上的冲突情况
	bool *bb = (bool*)malloc(sizeof(bool) * (n+n));		// 维护正斜线上的冲突情况
	bool *cc = (bool*)malloc(sizeof(bool) * (n+n));		// 维护反斜线上的冲突情况

	for( i = 0; i < n; i++ )
	{
	    // 各斜线上皇后数量置0
		b[i] = 0;
		c[i] = 0;

		bb[i] = false;
		cc[i] = false;

		// 这样设置满足约束条件行列不冲突
		queen[i] = i;
	}

	for( i = n; i < n+n; i++ )
	{
	    // 重置剩余斜线的皇后数量
		b[i] = 0;
		c[i] = 0;

		bb[i] = false;
		cc[i] = false;
	}

    // 放置前n个不冲突的皇后
	for( i = 0,last = n; i < m; i++,last--)
	{
		do
		{
			z = i + BRandom(last);	//BRandom: 在区间[0,last)内的随机数
		}
		while ( bb[i-queen[z]+n-1] || cc[i+queen[z]] );


		swap(queen[i], queen[z]);

		b[i-queen[i]+n-1]++;
		c[i+queen[i]]++;
		bb[i-queen[i]+n-1] = true;
		cc[i+queen[i]] = true;
	}

    // 随机初始化后n-m个可能冲突的皇后
	for( i = m, last = n-m; i < n; i++, last--)
	{
		z = i + BRandom(last);
		swap(queen[i], queen[z]);
		b[i-queen[i]+n-1]++;
		c[i+queen[i]]++;
	}

	free(bb);
	free(cc);
}

// 求出皇后冲突数，并以此作为启发值
ll sum(const ll queen[], const ll n, const ll b[], const ll c[])
{
	ll ans = 0;
	ll i;

	for (i = 0; i < n+n; i++)
	{
		if (b[i] > 1)
			ans += b[i] * (b[i]-1)/2;
		if (c[i] > 1)
			ans += c[i] * (c[i]-1)/2;
	}

	return ans;
}

// 求出如果将i行与j行的皇后交换后，皇后冲突数的改变值
ll delta(ll i, ll j, ll b[], ll c[], const ll q[]/*queen*/, ll n)
{
	ll ans = 0;

	ans += 1 - b[i-q[i]+n-1];
	ans += 1 - c[i+q[i]];
	ans += 1 - b[j-q[j]+n-1];
	ans += 1 - c[j+q[j]];

	ans +=	b[j-q[i]+n-1];
	ans +=	c[j+q[i]];
	ans +=	b[i-q[j]+n-1];
	ans +=	c[i+q[j]];

	if ( (i+q[i]==j+q[j]) || (i-q[i]==j-q[j]) )	// 在同一斜线上
		ans += 2;
	return ans;
}

// Queen Search 4 算法
void QS4()
{
	ll t;		// 当前冲突数，即启发值
	ll temp;	// 变化冲突数
	ll i,j;

    ll* queen = (ll*)malloc( sizeof(ll) * n);	// 皇后的解
	ll* b = (ll*)malloc( sizeof(ll) * (n+n) );	// 维护对角线上的冲突数
	ll* c = (ll*)malloc( sizeof(ll) * (n+n) );	// 维护对角线上的冲突数

	cout<<"initioning"<<endl;
	init_4(queen,n,m,b,c);
	t = sum(queen,n,b,c);
	cout<<"Confilicts: "<<t<<endl;

	while (t>0)
	{
		temp = 0;

        // 遍历后可能冲突的n-m个皇后
		for (i = m; i < n; i++)
            // 运气好，该皇后不与其他皇后发生冲突
            if ((b[i-queen[i]+n-1]==1) && (c[i+queen[i]]==1)) continue;

            // 若是冲突皇后,从第一个开始，找一个与该皇后交换后冲突数减少的皇后
            else
            {
                for (j = 0; j < n; j++)
                if(i!=j)    // 肯定不能是同一个皇后
                {
                    temp = delta(i,j,b,c,queen,n);  // 判断交换后能否减少冲突数
                    if (temp < 0) break;    // 若能减少冲突
                }
                if (temp < 0) break;
            }

        // 若交换这两个皇后能够减少冲突数，交换皇后，并且修正交换前后受影响斜线的皇后数
		if (temp < 0)
		{
			b[i-queen[i]+n-1]--;
			c[i+queen[i]]--;
			b[j-queen[j]+n-1]--;
			c[j+queen[j]]--;

			swap(queen[i], queen[j]);

			b[i-queen[i]+n-1]++;
			c[i+queen[i]]++;
			b[j-queen[j]+n-1]++;
			c[j+queen[j]]++;

			t += temp;  // 更正冲突数
		}
		// 该冲突皇后找不到能够交换的皇后，陷入局部最优解，则重启！
		else
		{
		    cout<<"initioning"<<endl;
			init_4(queen,n,m,b,c);
			t = sum(queen,n,b,c);
			cout<<"Confilicts: "<<t<<endl;
		}
	}

	// 将符合条件 N 皇后的编码输出到文件
	for (i = 0; i < n; i++)		fprintf(out, "%lld ", queen[i]);

	free(queen);
	free(b);
	free(c);
}
