# 文件使用简介

该文件夹内包含三个压缩包，最终程序的.py文件已经被压缩成为new_nqueens.zip
编译器用的是pycharm，创建了虚拟环境，解压new_nqueens.zip后目录：new_nqueens/venv下的nqueen.py文件是n皇后解的源代码；million_queen_code.txt文件存入的是n皇后的一个解；check.py是检查解是否合法的源代码。
另外两个压缩包是历史代码。
main.cpp是用c++写的解决方案，更快，但是是后写的。人工智能还是喜欢用python。

还有一个docx文件是一份报告。